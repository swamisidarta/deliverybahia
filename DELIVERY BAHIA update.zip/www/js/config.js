
var krms_config ={	
	'ApiUrl' : "http://www.deliverybahia.com.br/mobileapp/api",
	'DialogDefaultTitle' : "Delivery Bahia",
	'pushNotificationSenderid' : "1065966392416",
	'facebookAppId' : "1093946037388382",
	'APIHasKey' : "aed53b0b562210e967d0d431ec42861b"
};